var preloader = document.getElementById('loading');
        function myFunction(){
            setInterval(() => {
                document.getElementById('loading').style.display = 'none'
            }, 2000)
        }


        setInterval(() => {
            document.getElementById('loading').style.display = 'none'
        }, 2000)